from pathlib import Path
import re,sys,shutil
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); p=root/'index.html'; s=p.read_text(encoding='utf-8')
if 'id="project01"' not in s or 'Daeseongjeon Architectural Digital Twin' in s: raise SystemExit('Unexpected or already updated index.html')
s=re.sub(r'(?i)(project\s*0)([123])',lambda m:m[1]+str(int(m[2])+1),s)
s=s.replace('<a href="#project02">Project 02</a>','<a href="#project01">Project 01</a>\n      <a href="#project02">Project 02</a>',1)
s=re.sub(r'(href="#project0[234]"><span class="num">0)([345])',lambda m:m[1]+str(int(m[2])+1),s)
marker='<a class="contents-item reveal" href="#project02">'; s=s.replace(marker,'<a class="contents-item reveal" href="#project01"><span class="num">03</span><span class="kr">전주향교 대성전</span><span class="en">Architectural Digital Twin</span></a>\n    '+marker,1)
section='''<!-- PROJECT 01 : 대성전 -->
<section id="project01" style="padding:0; border-bottom:1px solid var(--line);">
<div class="project-hero"><video autoplay muted loop playsinline poster="Hanok/main%20render.webp"><source src="Hanok/Daeseongjeon_Portfolio_Short.mp4" type="video/mp4"></video><div class="ph-overlay"></div><div class="ph-content"><div class="eyebrow" style="margin-bottom:8px;">Project 01 — Architectural Digital Twin</div><div class="project-title">Daeseongjeon Architectural Digital Twin <span style="font-size:16px; font-family:var(--body); font-weight:500; color:var(--ink-soft); display:block; margin-top:8px;">전주향교 대성전 · 실제 건축 도면 기반 디지털 재현</span></div><div class="project-sub">Blender · Substance Painter · Unreal Engine · Generative AI</div></div></div>
<div class="project-body">
'''
def frame(file,caption):return f'<div class="render-frame board-frame reveal"><img loading="lazy" src="Hanok/{file}" alt="{caption}"></div><div class="cap-label" style="margin-bottom:50px;">{caption}</div>\n'
def heading(t):return f'<div class="eyebrow reveal" style="margin-bottom:18px;">{t}</div>\n'
def note(t):return f'<p class="note-text reveal" style="max-width:900px;font-size:15px;margin-bottom:36px;">{t}</p>\n'
section+=frame('main%20render.webp','Final Render — 전주향교 대성전')+note('실제 건축 도면을 기반으로 대성전의 치수와 비례를 재현하고, 전통 목조 건축 구조를 모듈 단위로 제작했습니다. Substance Painter를 활용한 재질 표현과 라이팅으로 건축물의 시각적 특징을 구현했습니다.')
section+=heading('Geometry Breakdown — Wireframe &amp; Clay')+frame('wireframe.webp','Wireframe — 메시 구성')+frame('wireframe_thik.webp','Wireframe — 건축 부재의 반복 구조')+frame('clay%20render.webp','Clay Render — 형태와 비례')+note('와이어프레임으로 메시와 반복 부재의 구성을 확인하고, 클레이 렌더로 재질 정보 없이 지붕의 곡선과 기둥, 창호의 비례를 검토했습니다.')
section+=heading('Modular Architecture — Exploded View')+frame('moduer_white.webp','Exploded View — 지붕 · 벽체 · 기둥 · 바닥 및 기단')
section+='<div class="detail-notes reveal" style="margin-bottom:60px;">'+''.join(f'<div class="note-row"><div class="note-title">{a}</div><div class="note-text">{b}</div></div>' for a,b in [('Roof','기와와 지붕 마루, 처마 및 하부 목조 부재를 분리하여 지붕의 곡선과 적층 구조를 구성했습니다.'),('Wall','벽체와 창호, 목재 프레임을 개별 파츠로 제작했습니다.'),('Column','기둥과 주초석, 수평 목조 부재를 분리하여 반복 배치와 조립을 고려했습니다.'),('Floor','바닥면, 석재 기단과 계단을 분리하여 하부 구조를 구성했습니다.')])+'</div>'
section+=heading('Material &amp; Weathering')+frame('door_detail.webp','Painted Wood — 창호 및 도색 디테일')+note('Substance Painter로 기와의 얼룩과 색상 편차, 목재의 도색 벗겨짐 및 표면 마모를 표현했습니다.')
section+=heading('AI-Assisted Texturing &amp; Modeling')+frame('sign_detail.webp','Signboard — 사진 기반 AI 현판 텍스처')+note('실제 현판 사진을 참고하여 AI로 서체와 색감, 질감을 재현한 이미지를 생성하고 텍스처로 가공해 적용했습니다.')+frame('roof_dregon.webp','Roof Ornament — 용두 장식 및 메시 수정')+note('비정형적인 용두 장식은 실제 사진 기반 스캔 텍스처와 AI 기반 3D 모델 생성을 활용했습니다. 생성된 모델의 형태와 폴리곤 구조를 직접 수정하고 텍스처를 적용하여 세부 형태와 표면의 노후화를 표현했습니다.')
section+=heading('Final Presentation — Turntable &amp; Cinematic')+frame('all_render.webp','Final Asset — 완성 모델')+('<div class="render-frame video-frame reveal"><video autoplay muted loop playsinline controls preload="metadata"><source src="Hanok/hanok_turntable_slow.mp4" type="video/mp4"></video></div><div class="cap-label" style="margin-bottom:50px;">360° Turntable</div>')+'<div class="render-frame video-frame reveal"><video controls playsinline preload="metadata" poster="Hanok/main%20render.webp"><source src="Hanok/Daeseongjeon_Portfolio_Short.mp4" type="video/mp4"></video></div><div class="cap-label">전주향교 대성전 — Cinematic Showcase</div></div></section>\n'
marker=re.search(r'<!-- PROJECT 02[^>]*-->',s)
if not marker: raise SystemExit('Project marker not found')
s=s[:marker.start()]+section+s[marker.start():]
marker='<div class="video-link-list">';s=s.replace(marker,marker+'\n<div class="video-link-row"><span class="vl-tag">영상링크 · PROJECT 01</span><a href="#project01">전주향교 대성전 — Cinematic</a></div>',1)
assert all(s.count(f'id="project0{i}"')==1 for i in range(1,5))
shutil.copytree(Path(__file__).parent/'Hanok',root/'Hanok',dirs_exist_ok=True)
p.write_text(s,encoding='utf-8');print('Updated index.html and Hanok assets')
